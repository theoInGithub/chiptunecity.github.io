import time
import random
import pgzrun
from pygame import mixer
from platformer import *

# Platformer constants
start_time = time.process_time()
TILE_SIZE = 18
ROWS = 30
COLS = 20
default_level = 1
wins = 0
platforms = None
obstacles = None
mushrooms = None
WIDTH = TILE_SIZE * ROWS
HEIGHT = TILE_SIZE * COLS
TITLE = "ChipTune City"
collectedshrooms = 0

over = False
win = False
deaths = 0
global gravity, jump_velocity, speed
gravity = 1
jump_velocity = -10
speed = 3
allow_skip = False

# Build world
def create_world(level):
    global platforms, obstacles, mushrooms, default_level
    platforms = build(f"levels/{level}platformer_platforms.csv", TILE_SIZE)
    obstacles = build(f"levels/{level}platformer_obstacles.csv", TILE_SIZE)
    mushrooms = build(f"levels/{level}platformer_mushrooms.csv", TILE_SIZE)

create_world(1)

# Initialize player
player = Actor("p_right")
player.bottomleft = (0, (HEIGHT - TILE_SIZE) * 0.6)
player.velocity_x = speed
player.velocity_y = speed - 3
player.jumping = False
player.alive = True

def draw():
    global over, collectedshrooms, deaths, win
    screen.clear()
    screen.fill("skyblue")
    for platform in platforms:
        platform.draw()
    for obstacle in obstacles:
        obstacle.draw()
    for mushroom in mushrooms:
        mushroom.draw()
    player.draw()
    if over:
        player.bottomleft = (0, HEIGHT - TILE_SIZE)
        deaths += 1
        player.visible = False
        time.sleep(0.5)
        player.visible = True
        over = False
    if win:
        global default_level
        default_level += 1
        create_world(default_level)
        player.bottomleft = (0, HEIGHT - TILE_SIZE)
        win = False

def update():
    global over, win, collectedshrooms
    if (keyboard.LEFT or keyboard.A) and player.midleft[0] > 0:
        player.x -= player.velocity_x
        player.image = "p_left"
        if player.collidelist(platforms) != -1:
            object = platforms[player.collidelist(platforms)]
            player.x = object.x + (object.width / 2 + player.width / 2)
    if (keyboard.RIGHT or keyboard.D) and player.midright[0] < WIDTH:
        player.x += player.velocity_x
        player.image = "p_right"
        if player.collidelist(platforms) != -1:
            object = platforms[player.collidelist(platforms)]
            player.x = object.x - (object.width / 2 + player.width / 2)
    player.y += player.velocity_y
    player.velocity_y += gravity
    if player.collidelist(platforms) != -1:
        object = platforms[player.collidelist(platforms)]
        if player.velocity_y >= 0:
            player.y = object.y - (object.height / 2 + player.height / 2)
            player.jumping = False
        else:
            player.y = object.y + (object.height / 2 + player.height / 2)
        player.velocity_y = 0
    if player.collidelist(obstacles) != -1:
        player.alive = False
        over = True
        player.bottomleft = (0, TILE_SIZE)
    for mushroom in mushrooms:
        if player.colliderect(mushroom):
            mushrooms.remove(mushroom)
            collectedshrooms += 1
    if len(mushrooms) == 0:
        win = True

def on_key_down(key):
    global allow_skip, win
    if (key == keys.UP or key == keys.W or key == keys.SPACE) and not player.jumping:
        player.velocity_y = jump_velocity
        player.jumping = True
    elif key == keys.M:
        mixer.quit()
    elif key == keys.S and allow_skip:
        win = True
    elif key == keys.E:
        print('Chiptune City: How to play')
        print('\nUse the arrow keys to Move and Jump')
    elif key == keys.ESCAPE:
        print("Exit ChipTune City...\nBye!...")
        quit()

pgzrun.go()
